# Atomic Service Components and Pricing (Granular)

## Technical SEO

### Crawl & Indexing

- ID: TECH-CRAWL-001
  Service: Website Crawl Setup
  Price: $80
  Unit: per website
  Notes: Configure crawler (Screaming Frog or equivalent)

- ID: TECH-CRAWL-002
  Service: Broken Links Detection
  Price: $70
  Unit: per website

- ID: TECH-CRAWL-003
  Service: Redirect Chain Analysis
  Price: $90
  Unit: per website

- ID: TECH-INDEX-001
  Service: XML Sitemap Creation
  Price: $100
  Unit: per website

- ID: TECH-INDEX-002
  Service: Sitemap Submission
  Price: $40
  Unit: per website

- ID: TECH-INDEX-003
  Service: Robots.txt Optimization
  Price: $60
  Unit: per website

- ID: TECH-INDEX-004
  Service: Index Coverage Analysis
  Price: $120
  Unit: per website

---

### Performance

- ID: TECH-PERF-001
  Service: Page Speed Audit
  Price: $90
  Unit: per website

- ID: TECH-PERF-002
  Service: Image Optimization
  Price: $80
  Unit: per 10 images

- ID: TECH-PERF-003
  Service: CSS/JS Minification Setup
  Price: $120
  Unit: per website

- ID: TECH-PERF-004
  Service: Lazy Loading Implementation
  Price: $100
  Unit: per website

- ID: TECH-PERF-005
  Service: Core Web Vitals Fix (LCP)
  Price: $150
  Unit: per website

- ID: TECH-PERF-006
  Service: Core Web Vitals Fix (CLS)
  Price: $120
  Unit: per website

---

### Architecture

- ID: TECH-ARCH-001
  Service: URL Structure Audit
  Price: $120
  Unit: per website

- ID: TECH-ARCH-002
  Service: URL Rewrite Recommendations
  Price: $100
  Unit: per website

- ID: TECH-ARCH-003
  Service: Internal Linking Audit
  Price: $130
  Unit: per website

- ID: TECH-ARCH-004
  Service: Internal Linking Fix
  Price: $150
  Unit: per website

---

## On-Page SEO

### Keyword & Mapping

- ID: ONPAGE-KW-001
  Service: Keyword Research (10 keywords)
  Price: $80
  Unit: per batch

- ID: ONPAGE-KW-002
  Service: Keyword Clustering
  Price: $90
  Unit: per batch

- ID: ONPAGE-KW-003
  Service: Keyword to Page Mapping
  Price: $100
  Unit: per 10 pages

---

### Page Optimization

- ID: ONPAGE-OPT-001
  Service: Title Tag Optimization
  Price: $20
  Unit: per page

- ID: ONPAGE-OPT-002
  Service: Meta Description Optimization
  Price: $20
  Unit: per page

- ID: ONPAGE-OPT-003
  Service: Header Tag Optimization
  Price: $25
  Unit: per page

- ID: ONPAGE-OPT-004
  Service: Image Alt Text Optimization
  Price: $15
  Unit: per page

- ID: ONPAGE-OPT-005
  Service: Content Keyword Optimization
  Price: $60
  Unit: per page

---

### Content Creation

- ID: CONTENT-001
  Service: Blog Writing (500 words)
  Price: $80
  Unit: per article

- ID: CONTENT-002
  Service: Blog Writing (1000 words)
  Price: $140
  Unit: per article

- ID: CONTENT-003
  Service: Landing Page Writing
  Price: $200
  Unit: per page

---

## Off-Page SEO

### Link Building

- ID: OFFPAGE-LINK-001
  Service: Prospect List Creation
  Price: $70
  Unit: per campaign

- ID: OFFPAGE-LINK-002
  Service: Outreach Email Campaign
  Price: $100
  Unit: per campaign

- ID: OFFPAGE-LINK-003
  Service: Backlink Acquisition
  Price: $120
  Unit: per link

---

### Authority

- ID: OFFPAGE-AUTH-001
  Service: Citation Submission (10 sites)
  Price: $90
  Unit: per batch

- ID: OFFPAGE-AUTH-002
  Service: Directory Submission (10 sites)
  Price: $80
  Unit: per batch

---

## Local SEO

- ID: LOCAL-001
  Service: Google Business Profile Creation
  Price: $120
  Unit: per business

- ID: LOCAL-002
  Service: GBP Optimization
  Price: $100
  Unit: per business

- ID: LOCAL-003
  Service: Local Citation Cleanup
  Price: $150
  Unit: per business

---

## Analytics & Tracking

- ID: ANALYTICS-001
  Service: GA4 Setup
  Price: $100
  Unit: per website

- ID: ANALYTICS-002
  Service: GSC Setup
  Price: $80
  Unit: per website

- ID: ANALYTICS-003
  Service: Event Tracking Setup
  Price: $150
  Unit: per website

---

## Strategy

- ID: STRATEGY-001
  Service: SEO Roadmap Creation
  Price: $300
  Unit: per project

- ID: STRATEGY-002
  Service: Competitor Gap Analysis
  Price: $200
  Unit: per project

---

## Reporting

- ID: REPORT-001
  Service: Monthly Report Generation
  Price: $120
  Unit: per month

- ID: REPORT-002
  Service: Dashboard Setup
  Price: $200
  Unit: per project

---

## Pricing Notes

- All prices are baseline values
- Apply multipliers:
  - Small: x1.0
  - Medium: x1.5
  - Large: x2.2

- Combine atomic units for package creation
- Use negotiation logic for:
  - discounts
  - bundling
  - urgency pricing