---
service_id: seo_migration_support
doc_type: service_concern_mapping
---

# SEO Migration Support – Concern Mapping

This document maps real-world user concerns to the SEO Migration Support service.  
Each scenario represents an atomic concern that maps directly to this service as the primary recommendation.

---

## Concern 1: Traffic Dropped After Website Redesign

### User Scenario
“After redesigning our website, our traffic dropped significantly.”

### Signals
- sharp traffic decline post-launch
- rankings dropped across multiple pages

### Root Issue
Improper migration handling (redirects, structure changes, indexing issues).

### Primary Service
SEO Migration Support

### Secondary Services
- Technical SEO Audit

---

## Concern 2: URLs Changed and Rankings Lost

### User Scenario
“We changed our URLs, and now our rankings are gone.”

### Signals
- old URLs not ranking
- new URLs not indexed or ranking

### Root Issue
Missing or incorrect redirect mapping.

### Primary Service
SEO Migration Support

---

## Concern 3: Website Moved to New Domain

### User Scenario
“We moved to a new domain, and traffic dropped.”

### Signals
- loss of domain authority signals
- reduced visibility

### Root Issue
Improper domain migration and signal transfer.

### Primary Service
SEO Migration Support

---

## Concern 4: Migration to New CMS Caused Issues

### User Scenario
“We moved from one platform to another, and SEO performance dropped.”

### Signals
- missing pages
- broken links
- indexing inconsistencies

### Root Issue
Technical issues introduced during CMS migration.

### Primary Service
SEO Migration Support

### Secondary Services
- Technical SEO Audit

---

## Concern 5: Redirects Not Working Properly

### User Scenario
“Old pages are not redirecting correctly to new pages.”

### Signals
- 404 errors
- redirect chains or loops

### Root Issue
Incorrect or incomplete redirect implementation.

### Primary Service
SEO Migration Support

---

## Concern 6: Pages Missing After Migration

### User Scenario
“Some pages disappeared after the migration.”

### Signals
- missing URLs
- drop in indexed pages

### Root Issue
Pages not transferred or improperly configured.

### Primary Service
SEO Migration Support

---

## Concern 7: Internal Links Broken After Migration

### User Scenario
“Many internal links are broken after the update.”

### Signals
- broken navigation
- crawl errors

### Root Issue
Internal linking not updated to reflect new structure.

### Primary Service
SEO Migration Support

### Secondary Services
- Technical SEO Audit

---

## Concern 8: Sudden Increase in Crawl Errors

### User Scenario
“Search Console shows many errors after migration.”

### Signals
- spike in crawl errors
- indexing issues

### Root Issue
Migration introduced technical inconsistencies.

### Primary Service
SEO Migration Support

---

## Concern 9: Rankings Dropped for Key Pages

### User Scenario
“Our most important pages lost rankings after migration.”

### Signals
- loss of top positions
- drop in impressions

### Root Issue
Loss of authority signals or improper mapping.

### Primary Service
SEO Migration Support

### Secondary Services
- On-Page SEO Optimization

---

## Concern 10: Duplicate Pages After Migration

### User Scenario
“After migration, we have duplicate versions of pages.”

### Signals
- duplicate URLs
- canonical issues

### Root Issue
Improper handling of URLs and canonical tags.

### Primary Service
SEO Migration Support

### Secondary Services
- Technical SEO Audit

---

## Concern 11: Sitemap and Indexing Issues

### User Scenario
“Our sitemap is not working correctly after migration.”

### Signals
- missing or outdated sitemap
- indexing inconsistencies

### Root Issue
Improper sitemap and indexing setup.

### Primary Service
SEO Migration Support

---

## Concern 12: Gradual Traffic Decline After Migration

### User Scenario
“Traffic is slowly declining after migration, not immediately.”

### Signals
- gradual drop in rankings
- delayed indexing issues

### Root Issue
Hidden migration issues affecting long-term performance.

### Primary Service
SEO Migration Support

### Secondary Services
- SEO Analytics & Reporting

---